drop database proyectoFINAL22025;

create database proyectoFINAL22025;

use proyectoFINAL22025;

create table productos(
id_producto int not null auto_increment,
marca varchar(30),
codigo int not null unique,
descripcion varchar(70),
stock boolean not null,
primary key(id_producto) 
);


ALTER TABLE productos auto_increment=1;



select * from productos;


insert into productos values (1,'Arcor',0123456789,'Fideos spaghetti x 500gr',1);

insert into productos values (2,'Luchetti',0987654321,'Arroz fino x 500gr',1);

insert into productos values (3,'Cuchuflito',0875964123,'Papel Higiénico 4 rollos x 75mts',1);
insert into productos values (4,'Pindonga',0678941235,'Mermelada x 600gr',1);

insert into productos values (5,'Hamlet',0883601787,'Chocolate en barra x 600gr',1);
insert into productos values (6,'Ledesma',0323872345,'Azúcar premium x 600gr',1);
insert into productos values (7,'Manaos',0850381215,'Bebida gaseosa x 1.5lts',1);
insert into productos values (8,'Cif',0970076024,'Limpiador multiuso x 700ml',1);

