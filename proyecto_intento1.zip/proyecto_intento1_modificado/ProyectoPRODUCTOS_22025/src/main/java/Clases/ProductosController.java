package Clases;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/ProductosController")
public class ProductosController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	
   public ProductosController() 
   {
       super();

   }
    
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ProductosDAO productosDAO=null;
		try 
		{
		productosDAO=new ProductosDAO();
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			System.out.println("cacheó una excepción");
		}
		
		String accion;
		RequestDispatcher dispatcher=null;
		
		accion=request.getParameter("accion");
		
		if(accion==null||accion.isEmpty())		
		{
			dispatcher=request.getRequestDispatcher("Vistas/Productos.jsp");
		}	
		else if(accion.equals("modificar"))
		{
			dispatcher=request.getRequestDispatcher("Vistas/modificar.jsp");
		}
		else if(accion.equals("actualizar"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			String marca=request.getParameter("marca");
			int codigo=Integer.parseInt(request.getParameter("codigo"));
			String descripcion=request.getParameter("descripcion");
				
			Productos producto=new Productos(id,marca,codigo,descripcion,true);			
			productosDAO.actualizarProducto(producto);
			
			dispatcher=request.getRequestDispatcher("Vistas/Productos.jsp");			
		}
		else if(accion.equals("eliminar"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			productosDAO.eliminarProducto(id);
			
			dispatcher=request.getRequestDispatcher("Vistas/Productos.jsp");
		}
		else if(accion.equals("nuevo"))
		{
			dispatcher=request.getRequestDispatcher("Vistas/nuevo.jsp");
		}
		else if(accion.equals("insert"))
		{
			
			int id=Integer.parseInt(request.getParameter("id"));
			String marca=request.getParameter("marca");
			int codigo=Integer.parseInt(request.getParameter("codigo"));
			String descripcion=request.getParameter("descripcion");
				
			Productos producto=new Productos(0,marca,codigo,descripcion,true);			
			productosDAO.insertarProducto(producto);	
			
			dispatcher=request.getRequestDispatcher("Vistas/Productos.jsp");

		}
		
		System.out.println("no tomo ninguno");
		dispatcher.forward(request, response);
		
		
		
	}
	
	
	
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
