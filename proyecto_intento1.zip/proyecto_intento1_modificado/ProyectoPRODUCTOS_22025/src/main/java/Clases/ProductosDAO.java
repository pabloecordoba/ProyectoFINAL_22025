package Clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductosDAO
{
	Connection conexion;
	
	public ProductosDAO() throws ClassNotFoundException
	{
		Conexion con=new Conexion();
		conexion=con.getConnection();
	}
	
	
	public List<Productos> listarProductos()
	{
		PreparedStatement ps;
		ResultSet rs;
		List<Productos> lista=new ArrayList<>();
		
		
		try
		{
			ps=conexion.prepareStatement("select * from productos");
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				int id=rs.getInt("id_producto");
				String marca=rs.getString("marca");
				int codigo=rs.getInt("codigo");
				String descripcion=rs.getString("descripcion");				
				boolean stock=rs.getBoolean("stock");
				
				Productos producto=new Productos(id,marca,codigo,descripcion,stock);
				lista.add(producto);
			}
			
		}
		catch(SQLException e)
		{
			System.out.println("Error de conexion");
			return null;			
		}
		
		
		
		return lista;		
		
		
	}
	
	
	
	public Productos mostrarProducto(int _id)
	{
		PreparedStatement ps;
		ResultSet rs;
		Productos producto=null;
		
		
		try
		{
			ps=conexion.prepareStatement("select * from productos where id_producto=?");
			ps.setInt(1, _id);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				int id=rs.getInt("id_producto");
				String marca=rs.getString("marca");
				int codigo=rs.getInt("codigo");
				String descripcion=rs.getString("descripcion");				
				boolean stock=rs.getBoolean("stock");
				
				producto=new Productos(id,marca,codigo,descripcion,stock);
											
			}	
			
			return producto;	
			
		}
		catch(SQLException e)
		{
			System.out.println("Error de conexion");
			return null;	
		}
		
		
		
	}
	
	
	
	public boolean insertarProducto(Productos producto)
	{
		PreparedStatement ps;
		try
		{
			ps=conexion.prepareStatement("insert into productos (marca,codigo,descripcion,estado) values (?,?,?,?)");
			ps.setString(1, producto.getMarca());
			ps.setInt(2, producto.getCodigo());
			ps.setString(3, producto.getDescripcion());			
			ps.setBoolean(4, producto.isStock());
			
			ps.execute();	
			
			return true;
		}
		catch(SQLException e)
		{
			System.out.println("Error de conexion");
			return false;			
		}	
	}
	
	public boolean actualizarProducto(Productos producto)
	{
		PreparedStatement ps;
		try
		{
			
			ps=conexion.prepareStatement("update productos set marca=?, codigo=?,descripcion=?,stock=? where id_producto=?");
			
			
			ps.setString(1, producto.getMarca());
			System.out.println("tomo getMarca");
			ps.setInt(2, producto.getCodigo());
			System.out.println("tomo getCodigo");
			ps.setString(3, producto.getDescripcion());
			System.out.println("tomo getDescripcion");
			ps.setBoolean(4, producto.isStock());
			System.out.println("tomo isStock");
			
			ps.execute();
			System.out.println("ejecutó genial");
			

			return true;
		}
		catch(SQLException e)
		{
			System.out.println("Error de conexion");
			return false;			
		}
	}
	
	
	
		public boolean eliminarProducto(int _id)
		{
			PreparedStatement ps;
			try
			{
				ps=conexion.prepareStatement("delete from productos where id_producto=?");
				ps.setInt(1, _id);
				ps.execute();	
				
				return true;		
			}
			catch(SQLException e)
			{
				System.out.println("Error de conexion");
				return false;			
			}

		}

	
}