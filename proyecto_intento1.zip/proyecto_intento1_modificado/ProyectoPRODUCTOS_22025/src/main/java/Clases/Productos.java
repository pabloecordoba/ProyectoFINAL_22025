package Clases;

public class Productos 
{
	private int id_producto;
	private String marca;
	private int codigo;
	private String descripcion;
	private boolean stock;
	
	
	
	public Productos(int id,String marca,int codigo,String descripcion,boolean stock)
	{
		this.setId_producto(id);     
		this.setMarca(marca);  
		this.setCodigo(codigo);
		this.setDescripcion(descripcion);
		this.setStock(stock);
	}
	
	
	
	
	public Productos()
	{
		super();
	}
	
	
	
	public int getId_producto() {
		return id_producto;
	}
	public void setId_producto(int id_producto) {
		this.id_producto = id_producto;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public boolean isStock() {
		return stock;
	}
	public void setStock(boolean stock) {
		this.stock = stock;
	}
	
	
	
	
}
